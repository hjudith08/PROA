<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROA</title>
    <!-- imagen de pestaña -->
    <link rel="icon" href="imagenes/LogosProaBlancoV3.png" type="image/png">
    <link rel="stylesheet" href="../../../css/estilosEli.css">
    <script src="../../../js/PopUpEntregas.js" defer></script>
    <!--<script src="js/FiltroTareas.js" defer></script>
    <script src="js/PopUpCerrarSesion.js" defer></script>-->

</head>
<body>
    <!--Aquí va el header-->
<header>
    <!--Aquí va el logo-->
    <a href="inicioGeneralProfesor(sergi).html">
        <img src="../../../../imagenes/LogosProaBlanco.png" alt="Logotipo">
    </a>
    <!--Aquí termina el logo-->

    <!--Aquí empieza la sección bienvenida-->
    <nav>
        <h3 class="titulo-asignatura">MATEMATICAS</h3>
        <p class="usuario-bienvenida">Bienvenido xexi mexi</p>
    </nav>

    <button popovertarget="menu-usuario" id="boton-usuario">
        <img src="../../../../imagenes/user_1b.png" alt="Usuario">
    </button>
    <div id="menu-usuario" popover anchor="boton-usuario">
        <p class="nombre-menu">Nombre Apellido</p>
        <div class="separador"></div>
        <div><button popovertarget="confirmar-cierre">Salir</button></div>
    </div>
    <!--Aquí ermina la sección bienvenida-->
</header>
<!--Aquí termina el header-->

<!--Aquí empieza la sección de la barra lateral-->
<aside class="sidebar">
    <nav class="menu-container">
        <button class="menu-btn" onclick="window.location.href='InicioAsignaturaProfesor.html';">
            <img src="../../../../imagenes/homeb.png" class="icono-menu" />
            <span>Inicio asignatura</span>
        </button>
        <button class="menu-btn activo">
            <img src="../../../../imagenes/libro-alt.png" class="icono-menu icono-activo" />
            <span class="texto-activo">Tareas</span>
        </button>
    </nav>
</aside>
<!--Aquí termina la sección de la barra lateral-->

<!--Aquí empieza la sección de tareas-->
<main class="contenido-principal">
    <div class="capa-fondo"></div>
<!-- Aquí va el botón volver-->
    <div class="botones-container">
        <div class="botonatras" onclick="window.location.href='Asignaturas.html'">
            <p>Asignaturas</p>
        </div>
    </div> 
<!-- Aquí termina el botón volver -->

<!--Aquí empieza TAREAS-->
    <div class="contenedor-tareas">
        <div class="cabecera-tareas">
            <h1>TAREAS</h1>
            <div class="grupo-botones-cabecera">
                <button  class="botones-cabecera-tareas">Eliminar tarea</button>
                <button  class="botones-cabecera-tareas">
                    <img class="icono-plus" src="../../../../imagenes/pluspurple.png" alt="plus">
                    Nueva tarea</button>
            </div>
        </div>

        <div class="tabla-flex-container">
            
            <!-- Encabezados -->
            <div class="fila-flex encabezado-flex">
                <div class="columna-flex-encabezado" id="nombre">Nombre tarea</div>
                <div class="columna-flex-encabezado" id="apertura">Fecha apertura</div>
                <div class="columna-flex-encabezado" id="apertura">Fecha entrega</div>
            </div>



            <!-- Filas de datos -->
             <div class="caja-tarea">
                <input class="checkbox trozo-caja-aparte" type="checkbox">
            <div class="fila-flex" onclick="window.location.href='InformacionTarea.html'" style="cursor: pointer;">
                <div class="columna-flex" id="titulo-tarea">Análisis de sucesiones y series de números reales</div>
                <div class="columna-flex" id="apertura">08/04/25</div>
                <div class="columna-flex" id="entrega">10/04/25</div>
                </div> 
                <div class="botones trozo-caja-aparte ">
                    <button class="botones-editar-entrega">Editar Tarea</button>
                    <button class="botones-editar-entrega">Ver entrega</button>
                </div>
            </div>

            <div class="caja-tarea">
                <input class="checkbox trozo-caja-aparte" type="checkbox">
            <div class="fila-flex" onclick="window.location.href='InformacionTareaEntregada.html'" style="cursor: pointer;">
                <div class="columna-flex">Resolución de sistemas de ecuaciones lineales</div>
                <div class="columna-flex">04/04/25</div>
                <div class="columna-flex">15/04/25</div>
                </div>
                <div class="botones trozo-caja-aparte ">
                    <button class="botones-editar-entrega">Editar Tarea</button>
                    <button class="botones-editar-entrega">Ver entrega</button>
                </div>
            </div>  
            <div class="caja-tarea">
                <input class="checkbox trozo-caja-aparte" type="checkbox">
            <div class="fila-flex" onclick="window.location.href='InformacionTarea.html'" style="cursor: pointer;">
                <div class="columna-flex">Análisis de funciones y estudio de sus gráficos</div>
                <div class="columna-flex">08/04/25</div>
                <div class="columna-flex">20/04/25</div>
                </div>
                <div class="botones trozo-caja-aparte ">
                    <button class="botones-editar-entrega">Editar Tarea</button>
                    <button class="botones-editar-entrega">Ver entrega</button>
                </div>
            </div>

            <div class="caja-tarea">
                <input class="checkbox trozo-caja-aparte" type="checkbox">
                <div class="fila-flex" onclick="window.location.href='InformacionTarea.html'" >
                <div class="columna-flex">Estudio de espacios vectoriales y subespacios</div>
                <div class="columna-flex">08/04/25</div>
                <div class="columna-flex">26/04/25</div>
                </div>
                <div class="botones trozo-caja-aparte ">
                   <button class="botones-editar-entrega">Editar Tarea</button>
                    <button class="botones-editar-entrega">Ver entrega</button>
                </div>
            </div>
        </div>
    </div>
</main>
<footer class="footer-anclado">
    <div class="footer-contenido">
        <div class="footer-poweredby">
            <span class="footer-texto">Powered by</span>
            <img src="../../../../imagenes/LogoEduSyncBlanco.png" alt="Logo Edusync" class="footer-logo">
        </div>
    </div>
</footer>
<!-- PopUp Cerrar Sesión -->
<div id="popupCerrarSesion" class="popup oculto">
    <div class="popup-contenido-C">
        <p class="popup-texto">¿Estás seguro que quieres cerrar sesión?</p>
        <div class="popup-botones">
            <button id="btn-si" class="boton-si">Sí</button>
            <button id="btn-no" class="boton-no">No</button>
        </div>
    </div>
</div>
<!--------------------------------------------------->
</body>
</html>