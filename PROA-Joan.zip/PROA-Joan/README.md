# PROA

=======
# Equipo 6 - Proa Edusync y todo lo dema :D

Cada uno tendrá sus Branches/Ramas que basicamente son extensiones del código principal, asi cada uno podrá subir su código tranquilamente y podremos poner en comun todos el si esta bien o no para subirlo a la Rama principal, que será la que entregaremos y subiremos al plesk
