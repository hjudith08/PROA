<?php
require_once 'includes/MySQL.inc';
// Validar conexión a la base de datos
if (!isset($conn)) {
    die("Error de conexión");
}

$mensaje = "No se proporcionó un token.";

// Validar el token por GET
if ($_SERVER['REQUEST_METHOD'] === 'GET' && !empty($_GET['token'])) {
    $token = $_GET['token'];

    $stmt = $conn->prepare("SELECT id, validez_token FROM usuarios WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($id, $validez_token);
        $stmt->fetch();

        // Validar si el token sigue siendo válido
        if (strtotime($validez_token) >= time()) {
            // Activar cuenta
            $update = $conn->prepare("UPDATE usuarios SET estado = 1, token = NULL, validez_token = NULL WHERE id = ?");
            $update->bind_param("i", $id);
            $update->execute();
            $update->close();

            $mensaje = "¡Registro validado correctamente!";
        } else {
            $mensaje = "El token ha expirado. Solicita un nuevo registro.";
        }
    } else {
        $mensaje = "Token no válido o ya fue utilizado.";
    }

    $stmt->close();
}

$conn->close();
?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Validar registro</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<h1>Validación de registro</h1>
<p><?= htmlspecialchars($mensaje) ?></p>
</body>
</html>
