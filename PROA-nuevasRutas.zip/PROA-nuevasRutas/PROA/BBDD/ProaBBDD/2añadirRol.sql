INSERT INTO rol (rol_id, nombre_rol, descripcion) VALUES
('alumno', 'Alumno', 'Estudiante matriculado'),
('profesor', 'Profesor', 'Personal docente'),
('pas', 'PAS', 'Personal de administración y servicios');
