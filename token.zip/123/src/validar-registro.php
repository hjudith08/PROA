<?php
require_once 'includes/MySQL.inc';

if (!isset($conn)) {
    die("Error de conexión");
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && !empty($_GET['token'])) {
    $token = $_GET['token'];

    $stmt = $conn->prepare("SELECT id, validez_token FROM usuarios WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($id, $validez_token);
        $stmt->fetch();

        if (strtotime($validez_token) >= time()) {
            $update = $conn->prepare("UPDATE usuarios SET estado = 1, token = NULL, validez_token = NULL WHERE id = ?");
            $update->bind_param("i", $id);
            $update->execute();
            $update->close();

            header("Location: app/mensaje.php?tipo=exito");
            exit;
        } else {
            header("Location: app/mensaje.php?tipo=expirado");
            exit;
        }
    } else {
        header("Location: app/mensaje.php?tipo=invalido");
        exit;
    }

    $stmt->close();
} else {
    header("Location: app/mensaje.php?tipo=sin_token");
    exit;
}

$conn->close();
?>
