<?php
$conexion = new mysqli("localhost", "jcatsen_123", "sh60Y9*v7", "test");

if ($conexion->connect_error) {
    die("❌ Error de conexión: " . $conexion->connect_error);
}

if (isset($_FILES["archivo"])) {
    $directorio = "uploads/";
    $nombre_original = basename($_FILES["archivo"]["name"]);
    $ruta = $directorio . $nombre_original;

    if (move_uploaded_file($_FILES["archivo"]["tmp_name"], $ruta)) {
        $stmt = $conexion->prepare("INSERT INTO archivos (nombre_original, ruta) VALUES (?, ?)");
        $stmt->bind_param("ss", $nombre_original, $ruta);
        $stmt->execute();
        $stmt->close();

        echo "✅ Archivo subido correctamente.<br>";
        echo "📁 Ruta guardada: <code>$ruta</code>";
    } else {
        echo "❌ Error al subir el archivo.";
    }
} else {
    echo "No se recibió ningún archivo.";
}

$conexion->close();
?>
