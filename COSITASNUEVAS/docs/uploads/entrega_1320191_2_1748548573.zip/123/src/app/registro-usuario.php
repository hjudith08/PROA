<?php
// Importaciones al principio
use PHPMailer\PHPMailer\PHPMailer;
require '../includes/PHPMailer.php';
require '../includes/SMTP.php';
require_once '../includes/MySQL.inc';

// Verificar conexión
if (!isset($conn)) die("Error de conexión");

// Generar token
$token = uniqid();

// Preparar inserción en base de datos
$stmt = $conn->prepare("INSERT INTO usuarios (nombre, apellidos, email, password, token, validez_token) 
VALUES (?, ?, ?, SHA2(?, 256), ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))");
$stmt->bind_param("sssss", $_POST['nombre'], $_POST['apellidos'], $_POST['email'], $_POST['password'], $token);
$stmt->execute();
$stmt->close();
$conn->close();

// Enviar correo
$mail = new PHPMailer(true);
$mail->isSMTP();
$mail->Host = 'smtp.ethereal.email';
$mail->SMTPAuth = true;
$mail->Username = 'lavinia71@ethereal.email';
$mail->Password = 'J1DUwV2GrtnSbKcDS7';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;

$mail->setFrom('registro@gti.com', 'GTI');
$mail->addAddress($_POST['email']);
$mail->isHTML(true);
$href = 'http://localhost/123/src/validar-registro.php?token=' . $token;
$mail->Subject = 'Registro de usuario';
$mail->Body = 'Hola <b>' . htmlspecialchars($_POST['nombre']) . ' ' . htmlspecialchars($_POST['apellidos']) . '</b>,<br>Por favor confirma tu registro: <a href="' . $href . '">' . $href . '</a>';
$mail->AltBody = 'Hola ' . $_POST['nombre'] . ' ' . $_POST['apellidos'] . ', confirma tu registro en: ' . $href;

$mail->send();
?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro</title>
</head>
<body>
<h1>Registro en proceso</h1>
<p>Se ha enviado un correo de confirmación a <?= htmlspecialchars($_POST['email']) ?></p>
</body>
</html>
