<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EduSync | Venta de Modulos Educativos</title>
    <!-- imagen de pestaña -->
    <link rel="icon" href="../../../imagenes/LogoEduSyncBlancoV3.png" type="image/png">
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<?php
include 'includes/menuConCuenta.inc';
?>


<h1>Esta es la landing page</h1>
</body>
</html>