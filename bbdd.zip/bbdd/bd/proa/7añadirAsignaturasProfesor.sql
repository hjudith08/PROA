-- Asignar 3 asignaturas a cada profesor
INSERT INTO profesores_asignaturas (dni_profesor, id_asignatura)
VALUES
    ('4525956', 101),
    ('4525956', 104),
    ('4525956', 105),

    ('6055365', 102),
    ('6055365', 106),
    ('6055365', 107),

    ('6738133', 103),
    ('6738133', 108),
    ('6738133', 109);
