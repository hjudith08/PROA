<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROA</title>
    <!-- imagen de pestaña -->
    <link rel="icon" href="imagenes/LogosProaBlancoV3.png" type="image/png">
    <link rel="stylesheet" href="../../../css/estilosJOAN.css">
    <script src="../../../js/PopUpEntregas.js" defer></script>
    <script src="../../../js/FiltroTareas.js" defer></script>
    <script src="../../../js/PopUpCerrarSesion.js" defer></script>
    <script src="../../../js/Responsive.js" defer></script>
    <script src="../../../js/InicioAsignatura.js" defer></script>
    <script src="../../../js/EditarTextoDesplegable.js" defer></script>
    <script src="../../../js/textotimeout.js" defer></script>
</head>
<body>
<header>
    <a href="inicioGeneralAlumno.html">
        <img src="../../../../imagenes/LogosProaBlanco.png" alt="Logotipo">
    </a>
    <nav>
        <h3 class="titulo-asignatura">MATEMATICAS</h3>
        <p class="usuario-bienvenida">Bienvenido Xexi Mexi</p>
    </nav>
    <button popovertarget="menu-usuario" id="boton-usuario">
        <img src="../../../../imagenes/user_1b.png" alt="Usuario">
    </button>
    <div id="menu-usuario" popover anchor="boton-usuario">
        <p class="nombre-menu">Xexi Mexi</p>
        <div class="separador"></div>
        <div><button popovertarget="confirmar-cierre">Salir</button></div>
    </div>
</header>
<aside class="sidebar">
    <nav class="menu-container">
        <button class="menu-btn" onclick="window.location.href='InicioAsignaturas.html';">
            <img src="../../../../imagenes/homeb.png" class="icono-menu"/>
            <span>Inicio asignatura</span>
        </button>
        <button class="menu-btn activo">
            <img src="../../../../imagenes/libro-alt.png" class="icono-menu icono-activo"/>
            <span class="texto-activo">Tareas</span>
        </button>
    </nav>
</aside>
    <nav class="menu-container">
        <button class="menu-btn" onclick="window.location.href='InicioAsignatura.php';">
            <img src="../../../../imagenes/homeb.png" class="icono-menu"/>
            <span>Inicio asignatura</span>
        </button>
        <button class="menu-btn activo">
            <img src="../../../../imagenes/libro-alt.png" class="icono-menu icono-activo"/>
            <span class="texto-activo">Tareas</span>
        </button>
    </nav>
</aside>
<main class="contenido-principal">
    <div class="capa-fondo"></div>
    <div class="botones-container">
        <div class="botonatras" onclick="window.location.href='InicioGeneral.html'">
            <p>Inicio General</p>
        </div>
        <div class="botonatras" onclick="window.location.href='Asignaturas.html'">
            <p>< Asignaturas</p>
        </div>
    </div>
    <div class="contenedor-tareas">
        <div class="cabecera-tareas">
            <h1>INFORMACIÓN DE LA TAREA</h1>
        </div>
        <div class="tabla-flex-container">
            <div class="info-tarea">
                <div class="fila"><span class="negrita">Título:</span> Análisis de sucesiones y series de números reales</div>
                <div class="fila"><span class="negrita">Estudiante:</span> Sergi Puig Biosca</div>
                <div class="fila"><span class="negrita">Fecha de envío:</span> 10/04/2025</div>
                <div class="fila"><span class="negrita">Calificación:</span> -</div>
                <div class="fila"><span class="negrita">Descripción de la tarea:</span></div>
                <div class="descripcion-tarea">
                    En esta asignatura se desarrollan habilidades de razonamiento lógico y resolución de problemas mediante el estudio de contenidos como álgebra, geometría, funciones, probabilidad y estadística. Se fomenta el pensamiento crítico y el uso de herramientas matemáticas en situaciones reales, promoviendo una comprensión sólida y aplicada del conocimiento.
                </div>
                <div class="info-tarea-acciones">
                    <label class="boton-rectangular">
                        <img src="../../../../imagenes/cloud-computing.png" alt="Icono subir archivo">
                        Subir archivo
                        <input type="file" style="display: none;">
                    </label>

                    <button class="boton-rectangular2" id="btn-enviar">ENTREGAR</button>
                </div>

                <!-- Mensaje oculto -->
            </div>
        </div>
    </div>
</main>
<footer class="footer-anclado">
    <div class="footer-contenido">
        <div class="footer-poweredby">
            <span class="footer-texto">Powered by</span>
            <img src="../../../../imagenes/LogoEduSyncBlanco.png" alt="Logo Edusync" class="footer-logo">
        </div>
    </div>
</footer>
<!-- PopUp Cerrar Sesión -->
<div id="popupCerrarSesion" class="popup oculto">
    <div class="popup-contenido-C">
        <p class="popup-texto">¿Estás seguro que quieres cerrar sesión?</p>
        <div class="popup-botones">
            <button id="btn-si" class="boton-si">Sí</button>
            <button id="btn-no" class="boton-no">No</button>
        </div>
    </div>
</div>
</body>
</html>