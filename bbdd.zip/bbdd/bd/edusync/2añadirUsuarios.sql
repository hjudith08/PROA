INSERT INTO usuarios (nombre, apellidos, email, password, estado)
VALUES
    ('Daniel', 'Palacio', 'dapasa@har.upv.es', '1234', 1),
    ('José Luis', 'Gimenez', 'jogilo@upvnet.upv.es', '4567', 1);
