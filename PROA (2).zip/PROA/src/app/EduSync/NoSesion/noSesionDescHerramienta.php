<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EduSync | Venta de Modulos Educativos</title>
    <link rel="icon" href="../../../../imagenes/LogoEduSyncBlancoV3.png" type="image/png">
    <link rel="stylesheet" href="../../../css/estilos.css">
</head>

<body>

<!-- header -->
    <?php include 'includes/edusyncNoSesionHeaderInclude.php'; ?>

<!-- primera sección información PROA -->
<section class="desc-section1">
    <div class="sec1-div">
        <div class="informacion-sec1">
            <!-- logo, informacion y boton PROA -->
            <img src="../../../../imagenes/LogosProaBlanco.png" alt="Logo PROA" class="logo-proa"><br>
            <p>Ayudamos a las instituciones a tener una mejor interacción entre alumnos 
                y profesores mediante módulos educativos con una interfaz más intuitiva, moderna y agradable, 
                formando parte de EduSync podrás acceder a pruebas exclusivas.</p>
            <a href="login.html" class="boton-probar">¡Prueba PROA Gratis!</a>
        </div>
        <!-- imagen proa ordenador -->
        <div class="informacion-sec2">
            <img src="../../../../imagenes/ordenador-proa.png" alt="Ordenador PROA" class="ordenador-proa">
        </div>
        <!-- flecha para bajar a la sección de como funciona la demo -->
        <div class="flecha-bajar-h">
        <a href="#desc-section2" class="boton-flecha">
            <span class="flecha"><img src="../../../../imagenes/down-arrow.png" alt="Boton bajar"></span>
        </a>
    </div>
    </div>
</section>
<!-- fin de la primera sección -->

<!-- segunda sección de como funciona la demo -->
<section class="desc-section2" id="desc-section2">
    <div class="container-sec2">
        <h2>¿Cómo funciona la demo?</h2>
        <div class="pasos-demo">
            <!-- 3 diferentes iconos y información -->
            <div class="paso">
                <div class="icono">
                    <img src="../../../../imagenes/keyb.png" alt="Icono Credenciales">
                </div>
                <h3>Solicita las credenciales</h3>
                <p>Te facilitaremos unas credenciales temporales para probar nuestro módulo con diferentes vistas</p>
            </div>
            <div class="paso">
                <div class="icono">
                    <img src="../../../../imagenes/demob.png" alt="Icono Demo">
                </div>
                <h3>Prueba la DEMO</h3>
                <p>Puedes ver todas las funcionalidades que podría tener tu web.</p>
            </div>
            <div class="paso">
                <div class="icono">
                    <img src="../../../../imagenes/cartb.png" alt="Icono Compra">
                </div>
                <h3>Compra PROA</h3>
                <p>Si te ha gustado ponte en contacto con nosotros para más información.</p>
            </div>
        </div>
    </div>
</section>
<!-- fin de la segunda sección -->

<!-- tercera sección información de PROA, imagen de fondo y texto -->
<section class="desc-section3">
    <div class="overlay-s3">
        <img src="../../../../imagenes/fotobg.png" alt="">
        <p>Nuestra demo educativa ofrece una experiencia interactiva y personalizada para estudiantes, permitiéndoles explorar conceptos de manera práctica y a su propio ritmo.<br><br>
            Con tecnología de vanguardia y simulaciones inmersivas, facilita un aprendizaje profundo y atractivo. <br>
            
            Además, su fácil integración en plataformas educativas existentes mejora la enseñanza sin complicaciones.<br> 
            
            Los educadores pueden hacer un seguimiento detallado del progreso de los estudiantes, optimizando la enseñanza en tiempo real. <br><br>
            
            ¡Descubre cómo esta herramienta puede transformar la educación de manera eficiente y accesible!</p>
    </div>
</section>
<!-- fin de la tercera sección -->

<!-- seccion en blanco, solo espacio en blanco -->
<section class="desc-white">
</section>
<!-- fin de la sección -->

<!-- cuarta sección información funcionalidad multiplataforma -->
<section class="desc-section4">
    <div class="contenedor-flex">
        <!-- imagen movil -->
        <div class="img-movil">
            <img src="../../../../imagenes/movil-proa.png" alt="Vista móvil">
        </div>
        <!-- titulo y texto -->
        <div class="texto-multiplataforma">
            <h2><strong>Funcionalidad multiplataforma</strong></h2>
            <p>
                App educativa multiplataforma accesible desde móvil, tablet y ordenador.<br>
                Sincronización en tiempo real y experiencia fluida para alumnos, docentes y familias.
            </p>
        </div>
    </div>
</section>
<!-- fin de la cuarta sección -->

<!-- quinta sección información funcionalidad multiplataforma -->
<section class="desc-section5">
    <div class="contenedor-flex">
        <!-- texto información -->
        <div class="texto-inferior">
            <p>
                La app tiene un diseño intuitivo y adaptable, con una interfaz clara y moderna que facilita la navegación en cualquier dispositivo.
                Su experiencia visual es atractiva y optimizada para un uso cómodo y eficiente.
            </p>
        </div>
        <!-- imagen tablet -->
        <div class="img-tablet">
            <img src="../../../../imagenes/tablet-proa.png" alt="Vista tablet/ordenador">
        </div>
    </div>
</section>
<!-- fin de la quinta sección -->

<!-- seccion en blanco, solo espacio en blanco -->
<section class="desc-white">
</section>
<!-- fin de la sección -->

<!-- footer -->
<footer class="footer">
    <div class="footer-container">
        <div class="footer-col">
            <p>Contáctanos: edusync@gti.com</p>
        </div>
        <div class="footer-col">
            <p>© 2025 - EduSync | Matriz de GTI</p>
        </div>
        <div class="footer-col">
            <img src="../../../../imagenes/GTIBlancosdsds.png" alt="Logo GTI">
        </div>
    </div>
</footer>

<!-- botón para volver arriba -->
<a href="#" class="scroll-to-top" aria-label="Subir al inicio">
    <img src="../../../../imagenes/high-arrowb.png" alt="Subir inicio pagina">
</a>

<!-- script para mostrar/ocultar el botón al hacer scroll -->
<script>
    const scrollBtn = document.querySelector('.scroll-to-top');

    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            scrollBtn.classList.add('visible'); // muestra el botón
        } else {
            scrollBtn.classList.remove('visible'); // oculta el botón
        }
    });
</script>
<!-- fin del script -->

</body>
</html>
