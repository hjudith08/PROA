<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROA</title>
    <!-- imagen de pestaña -->
    <link rel="icon" href="imagenes/LogosProaBlancoV3.png" type="image/png">
    <link rel="stylesheet" href="src/css/estilos.css">

</head>
<body>

<?php
include 'src/app/Proa/includes/sss.php';
?>

</body>
</html>