<?php
// apaño temporal para evitar el login
//llamo al archivo json de usuarios y lo guardo en una variable
$usuarios = file_get_contents('src/api/v0.0/data/usuariosProa.json');
//decodifico el json y lo guardo en una variable
$usuarios = json_decode($usuarios, true);
//busco el usuario que tenga el id 0 y lo guardo en una variable
$userdata = $usuarios[0];

// require_once 'control-ventas.inc.php';

?>

<header>
    <a href="index.php">
        <img src="imagenes/LogosProaBlanco.png" alt="Logotipo">
    </a>
    <nav>
        <!--<h3 class="titulo-asignatura"><?php echo $asignaturas['seleccion']; ?></h3>-->
        <h3 class="titulo-asignatura">Algebra Matricial y Geometría</h3>

        <ul>
            <!--<div>Bienvenido <?php echo $userdata['nombre'] . " " . $userdata['apellidos'];?>!</div> -->
            <p class="usuario-bienvenida">Bienvenido xexi mexi</p>
        </ul>
    </nav>
    <button popovertarget="menu-usuario"><img src="imagenes/user_1b.png" alt=""></button>
    <div id="menu-usuario" popover>
        <!--<div><?php echo $userdata['nombre'] . " " . $userdata['apellidos'];?>!</div> -->
        <p class="nombre-menu">xexi mexi</p>
        <div><button popovertarget="confirmar-cierre">Salir</button></div>
    </div>
</header>
<aside class="sidebar">
    <nav class="menu-container">
        <button class="menu-btn" onclick="window.location.href='InicioAsignatura.php';">
            <img src="imagenes/homeb.png" class="icono-menu" />
            <span>Inicio asignatura</span>
        </button>
        <button class="menu-btn activo">
            <img src="imagenes/libro-alt.png" class="icono-menu icono-activo" />
            <span class="texto-activo">Tareas</span>
        </button>
    </nav>
</aside>
<main class="contenido-principal">
    <!-- INFORMACIÓN ASIGNATURA -->
    <section class="info-asignatura">
        <div class="info-cabecera">
            <h2>INFORMACIÓN ASIGNATURA</h2>
        </div>
        <div class="info-cuerpo">
            <!-- Contenido de la asignatura aquí -->
            <p>Detalles sobre la asignatura, profesor, objetivos, etc.</p>
        </div>
    </section>

    <!-- TAREAS -->
    <section class="tareas">
        <h3>TAREAS</h3>
        <div class="tareas-cuerpo">
            <!-- Lista de tareas aquí -->
            <p>No hay tareas pendientes.</p>
        </div>
    </section>
</main>


<footer class="footer-anclado">
    <div class="footer-contenido">
        <div class="footer-poweredby">
            <span class="footer-texto">Powered by</span>
            <img src="imagenes/LogoEduSyncBlanco.png" alt="Logo Edusync" class="footer-logo">
        </div>
    </div>
</footer>

<!-- Popover de confirmación -->
<div id="confirmar-cierre" popover>
    <p>¿Estas seguro que quieres cerrar sesión?</p>
    <div>
        <button onclick="cerrarSesion()">Si</button>
        <button onclick="document.getElementById('confirmar-cierre').hidePopover()">No</button>
    </div>
</div>


<script>
    function cerrarSesion() {
        // Redirige al script de cierre de sesión real
        window.location.href = "../../../"; // o el archivo PHP que uses
    }
</script>
<script src="js/FiltroTareas.js"></script>