INSERT INTO grupos (grupo_id, nombre_grupo, descripcion) VALUES
    ('001', 'Grupo para sprint', 'Grupo inicial de PROA para el sprint');