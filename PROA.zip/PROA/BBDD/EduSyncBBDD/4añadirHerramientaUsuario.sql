INSERT INTO usuarios_herramientas (usuario_id, herramienta_id)
VALUES
    (1, 1),
    (2, 1);