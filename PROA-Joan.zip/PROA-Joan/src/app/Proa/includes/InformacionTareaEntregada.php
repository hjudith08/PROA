<?php
// apaño temporal para evitar el login
//llamo al archivo json de usuarios y lo guardo en una variable
$usuarios = file_get_contents('src/api/v0.0/data/usuariosProa.json');
//decodifico el json y lo guardo en una variable
$usuarios = json_decode($usuarios, true);
//busco el usuario que tenga el id 0 y lo guardo en una variable
$userdata = $usuarios[0];

// require_once 'control-ventas.inc.php';

?>

<header>
    <a href="index.php">
        <img src="imagenes/LogosProaBlanco.png" alt="Logotipo">
    </a>
    <nav>
        <!--<h3 class="titulo-asignatura"><?php echo $asignaturas['seleccion']; ?></h3>-->
        <h3 class="titulo-asignatura">Algebra Matricial y Geometría</h3>

        <ul>
            <!--<div>Bienvenido <?php echo $userdata['nombre'] . " " . $userdata['apellidos'];?>!</div> -->
            <p class="usuario-bienvenida">Bienvenido xexi mexi</p>
        </ul>
    </nav>
    <button popovertarget="menu-usuario"><img src="imagenes/user_1b.png" alt=""></button>
    <div id="menu-usuario" popover>
        <!--<div><?php echo $userdata['nombre'] . " " . $userdata['apellidos'];?>!</div> -->
        <p class="nombre-menu">xexi mexi</p>
        <div><button popovertarget="confirmar-cierre">Salir</button></div>
    </div>
</header>
<aside class="sidebar">
    <nav class="menu-container">
        <button class="menu-btn" onclick="window.location.href='InicioAsignatura.php';">
            <img src="imagenes/homeb.png" class="icono-menu" />
            <span>Inicio asignatura</span>
        </button>
        <button class="menu-btn activo">
            <img src="imagenes/libro-alt.png" class="icono-menu icono-activo" />
            <span class="texto-activo">Tareas</span>
        </button>
    </nav>
</aside>
<main class="contenido-principal">
    <div class="capa-fondo"></div>
    <div class="contenedor-tareas">
        <div class="cabecera-tareas">
            <h1>INFORMACIÓN DE LA TAREA</h1>
        </div>
        <div class="tabla-flex-container">
            <div class="tabla-flex-container">
                <div class="info-tarea">
                    <div class="fila"><span class="negrita">Título:</span> Análisis de sucesiones y series de números reales</div>
                    <div class="fila"><span class="negrita">Estudiante:</span> Sergi Puig Biosca</div>
                    <div class="fila"><span class="negrita">Fecha de envío:</span> 10/04/2025</div>
                    <div class="fila"><span class="negrita">Calificación:</span> -</div>
                    <div class="fila"><span class="negrita">Descripción de la tarea:</span></div>
                    <div class="descripcion-tarea">
                        En esta asignatura se desarrollan habilidades de razonamiento lógico y resolución de problemas mediante el estudio de contenidos como álgebra, geometría, funciones, probabilidad y estadística. Se fomenta el pensamiento crítico y el uso de herramientas matemáticas en situaciones reales, promoviendo una comprensión sólida y aplicada del conocimiento.
                    </div>
                    <div class="info-tarea-acciones">
                        <button class="boton-rectangular">
                            <img src="./imagenes/cloud-computing.png" alt="Icono subir archivo">
                            Subir archivo
                        </button>
                        <button class="boton-block">ENTREGAR</button>
                    </div>
                </div>
            </div>

        </div>
    </div>
</main>

<footer class="footer-anclado">
    <div class="footer-contenido">
        <div class="footer-poweredby">
            <span class="footer-texto">Powered by</span>
            <img src="imagenes/LogoEduSyncBlanco.png" alt="Logo Edusync" class="footer-logo">
        </div>
    </div>
</footer>

<!-- Popover de confirmación -->
<div id="confirmar-cierre" popover>
    <p>¿Estas seguro que quieres cerrar sesión?</p>
    <div>
        <button onclick="cerrarSesion()">Si</button>
        <button onclick="document.getElementById('confirmar-cierre').hidePopover()">No</button>
    </div>
</div>


<script>
    function cerrarSesion() {
        // Redirige al script de cierre de sesión real
        window.location.href = "../../../"; // o el archivo PHP que uses
    }
</script>
<script src="js/FiltroTareas.js"></script>