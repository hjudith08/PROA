<footer class="footer">
    <div class="footer-container">
        <div class="footer-col">
            <p>Contáctanos: edusync@gti.com</p>
        </div>
        <div class="footer-col">
            <p>© 2025 - EduSync | Matriz de GTI</p>
        </div>
        <div class="footer-col">
            <img src="../../../imagenes/GTIBlancosdsds.png" alt="Logo GTI">
        </div>
    </div>
</footer>