<?php
$conexion = new mysqli("jcatsen.upv.edu.es:3306", "jcatsen_123", "sh60Y9*v7", "test");
// Verifica la conexión
if ($conexion->connect_error) {
    die("❌ Error de conexión: " . $conexion->connect_error);
}

// Crear tabla si no existe
$tabla = "CREATE TABLE IF NOT EXISTS archivos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_original VARCHAR(255),
    ruta VARCHAR(255),
    fecha_subida DATETIME DEFAULT CURRENT_TIMESTAMP
)";

if ($conexion->query($tabla) === TRUE) {
    echo "✅ Tabla 'archivos' creada correctamente en la base de datos 'test'.";
} else {
    echo "❌ Error creando la tabla: " . $conexion->error;
}

$conexion->close();
?>
