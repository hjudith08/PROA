
    <header>
        <a href="#" class="logo">
            <img src="/imagenes/logo-edusync.png" alt="EduSync Logo">
        </a>
        <nav>
            <ul>
                <li><a href="#" class="enlace-nav">Contacto</a></li>
                <li><input type="button" class="boton-login" value="Login"></li>
            </ul>
        </nav>
        <button class="boton-menu-movil">☰</button>
    </header>
